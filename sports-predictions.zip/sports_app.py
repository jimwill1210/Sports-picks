import streamlit as st
import pandas as pd
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.model_selection import train_test_split

from mlb_utils import get_mlb_schedule, build_mlb_features
from nfl_utils import get_nfl_schedule, get_nfl_team_stats, build_nfl_features

st.title("🏈⚾ Sports Prediction App")
st.write("Predicts upcoming MLB & NFL games and filters ≥60% win probability.")

def run_model(df, threshold=0.60):
    X = df.drop(columns=["result"])
    y = df["result"]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )

    model = GradientBoostingClassifier()
    model.fit(X_train, y_train)

    probs = model.predict_proba(X_test)[:, 1]
    results = pd.DataFrame({
        "Index": X_test.index,
        "Win_Prob": probs,
        "Prediction": (probs >= 0.5).astype(int),
        "Actual": y_test.values
    })

    strong = results[results["Win_Prob"] >= threshold]
    return results, strong

choice = st.sidebar.selectbox("Choose Sport", ["MLB (Today)", "NFL (Upcoming)"])

if choice == "MLB (Today)":
    st.subheader("Upcoming MLB Games")
    games = get_mlb_schedule()
    if not games.empty:
        features = build_mlb_features(games)
        preds, strong = run_model(features)
        st.dataframe(strong)
    else:
        st.write("No MLB games scheduled today.")

elif choice == "NFL (Upcoming)":
    st.subheader("Upcoming NFL Games")
    schedule = get_nfl_schedule()
    stats = get_nfl_team_stats()
    features = build_nfl_features(schedule, stats)
    preds, strong = run_model(features)
    st.dataframe(strong)
