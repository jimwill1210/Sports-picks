import pandas as pd
import requests

def get_nfl_schedule(year=2025):
    url = f"https://www.pro-football-reference.com/years/{year}/games.htm"
    tables = pd.read_html(url)
    df = tables[0]
    df = df[df["PtsW"].isna()]
    return df[["Week", "Winner/tie", "Loser/tie"]].rename(columns={"Winner/tie": "Away", "Loser/tie": "Home"})

def get_nfl_team_stats(year=2024):
    url = f"https://www.pro-football-reference.com/years/{year}/"
    tables = pd.read_html(url)
    df = tables[0]
    df = df.dropna(subset=["PF", "PA"])
    df = df.rename(columns={"PF": "Points_For", "PA": "Points_Against"})
    df["PPG"] = df["Points_For"] / 17
    df["PAPG"] = df["Points_Against"] / 17
    return df[["Team", "PPG", "PAPG"]]

def build_nfl_features(schedule_df, stats_df):
    rows = []
    for _, g in schedule_df.iterrows():
        home = g["Home"]
        away = g["Away"]

        home_stats = stats_df[stats_df["Team"].str.contains(home, na=False)]
        away_stats = stats_df[stats_df["Team"].str.contains(away, na=False)]

        if home_stats.empty or away_stats.empty:
            continue

        rows.append({
            "PPG_diff": float(home_stats["PPG"]) - float(away_stats["PPG"]),
            "PAPG_diff": float(away_stats["PAPG"]) - float(home_stats["PAPG"]),
            "home_adv": 1,
            "result": 0
        })
    return pd.DataFrame(rows)
