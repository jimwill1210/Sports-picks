# 🏈⚾ Sports Prediction App

Predicts MLB & NFL games with real stats. Shows picks ≥60% win probability.

## Run locally
```bash
pip install -r requirements.txt
streamlit run sports_app.py
```

## Deploy to Streamlit Cloud
1. Push this repo to GitHub.
2. Go to [https://share.streamlit.io](https://share.streamlit.io).
3. Link your repo and deploy.
