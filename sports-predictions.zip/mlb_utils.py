import requests
import pandas as pd
import datetime

def get_mlb_schedule(date=None):
    if date is None:
        date = datetime.date.today().strftime("%Y-%m-%d")
    url = f"https://statsapi.mlb.com/api/v1/schedule?sportId=1&date={date}&expand=schedule.teams"
    data = requests.get(url).json()
    games = []
    for d in data.get("dates", []):
        for g in d.get("games", []):
            games.append({
                "home_team": g["teams"]["home"]["team"]["name"],
                "away_team": g["teams"]["away"]["team"]["name"]
            })
    return pd.DataFrame(games)

def get_team_id(team_name):
    url = "https://statsapi.mlb.com/api/v1/teams?sportId=1"
    teams = requests.get(url).json()["teams"]
    for t in teams:
        if team_name.lower() in t["name"].lower():
            return t["id"]
    return None

def get_team_stats(team_id, season=2025):
    url = f"https://statsapi.mlb.com/api/v1/teams/{team_id}/stats?stats=season&season={season}"
    data = requests.get(url).json()
    try:
        splits = data["stats"][0]["splits"][0]["stat"]
        return {
            "OPS": float(splits.get("ops", 0)),
            "ERA": float(splits.get("era", 0))
        }
    except:
        return {"OPS": 0, "ERA": 0}

def build_mlb_features(games_df):
    rows = []
    for _, g in games_df.iterrows():
        home_id = get_team_id(g["home_team"])
        away_id = get_team_id(g["away_team"])
        if not home_id or not away_id:
            continue
        home_stats = get_team_stats(home_id)
        away_stats = get_team_stats(away_id)

        rows.append({
            "OPS_diff": home_stats["OPS"] - away_stats["OPS"],
            "ERA_diff": away_stats["ERA"] - home_stats["ERA"],
            "home_adv": 1,
            "result": 0
        })
    return pd.DataFrame(rows)
